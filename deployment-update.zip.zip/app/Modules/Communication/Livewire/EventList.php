<?php

namespace App\Modules\Communication\Livewire;

use App\Modules\Communication\Models\Event;
use Livewire\Component;
use Livewire\WithPagination;

class EventList extends Component
{
    use WithPagination;

    public string $search = '';
    public string $statusFilter = '';

    protected $queryString = ['search', 'statusFilter'];

    public function updatingSearch(): void
    {
        $this->resetPage();
    }

    public function updatingStatusFilter(): void
    {
        $this->resetPage();
    }

    public function delete(int $id): void
    {
        $event = Event::findOrFail($id);
        $event->delete();
        $this->dispatch('notify', message: 'Event deleted successfully.', type: 'success');
    }

    public function render()
    {
        $events = Event::with('creator')
            ->when($this->search, fn ($q) => $q->where('title', 'like', "%{$this->search}%")
                ->orWhere('description', 'like', "%{$this->search}%")
                ->orWhere('location', 'like', "%{$this->search}%"))
            ->when($this->statusFilter, fn ($q) => $q->where('status', $this->statusFilter))
            ->orderByDesc('start_date')
            ->paginate(15);

        return view('communication::livewire.event-list', [
            'events' => $events,
        ]);
    }
}
